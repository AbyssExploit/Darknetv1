#!/system/xbin/bash
#abysswalker
#recodelu_memang_nub

blue='\033[34;1m'
green='\033[32;1m'
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'
yellow='\033[33;1m'
sleep 1

figlet Abyss Walker | lolcat
figlet Mix Tools | lolcat



echo -e " Welcome To Mix Tools Deface" | lolcat
echo ""
echo -e " Author    : Abyss Walker" | lolcat
echo -e " Youtube   : Abyss Walker" | lolcat
echo -e " Instagram : abysswalker260" | lolcat
echo -e " Facebook  : Abyss Project" | lolcat
echo ""
echo -e " ∆ Silahkan Pilih Tools Yang Ingin Kalian Install ∆" | lolcat
echo ""
echo " Tools Deface, Hack Website, DDOS, DLL Siap Di Gunakan "
echo "                 Do With You Own Risk!! "

echo -e "__________________________________" | lolcat
echo -e "1.Tools RED HAWK " | lolcat
echo "__________________________________"
echo -e "2.Tools DDOS XERXES " | lolcat
echo "__________________________________"
echo -e "3.Tools SQL Injection" | lolcat
echo "__________________________________"
echo -e "4.Tools SQL Scan " | lolcat
echo "__________________________________"
echo -e "5.Tools XSStrike" | lolcat
echo "__________________________________"
echo -e "6.Tools Ip-Attack (Nmap,Iptrack,dll) " | lolcat
echo "__________________________________"
echo -e "7.Tools WebSploit" | lolcat
echo "__________________________________"
echo -e "8.Tools Google Dork ( Dorking Google )" | lolcat
echo "__________________________________"
echo -e "9.Tools Admin Login Finder " | lolcat
echo "__________________________________"
echo -e "10.Tools Vuln Search " | lolcat
echo "__________________________________"
echo -e "11.Tools Google Dork 2 (DDOS) " | lolcat
echo "__________________________________"
echo -e "12.Tools NMAP " | lolcat
echo "__________________________________"
echo -e "13.Tools Google Dork V2 " | lolcat
echo "__________________________________"
echo -e "14.Tools Vulnx (Bot Auto Shell Injector)" | lolcat
echo "__________________________________"
echo -e "15.Masih Kurang? Klik Ini" | lolcat
echo ""
echo -e "0.Keluar" | lolcat
echo ""
read -p "Root@AbyssWalker ~# " asu


if [ $asu = 1 ] || [ $asu = 1 ]
then
clear
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
apt install git
apt install php
git clone https://github.com/Tuhinshubhra/RED_HAWK
mv RED_HAWK $HOME
cd $HOME/RED_HAWK
php rhawk.php
fi


if [ $asu = 2 ] || [ $asu = 2 ]
then
clear
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
apt install git
apt install php
apt install openssh
apt install clang -y
pip2 install mechanize
git clone https://github.com/TheSploit/Xerxes
mv Xerxes $HOME
cd $HOME/Xerxes
gcc xerxes.c -o  xerxes
clear
echo "Untuk Selanjutnya Ketik"
echo "./xerxes (web atau ip target) (port)"
echo "Contoh"
echo "./Xerxes www.test.com 80"
fi

if [ $asu = 3 ] || [ $asu = 3 ]
then
clear
figlet Darknet | lolcat
echo -e "Auto Install" | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
apt install git
git clone https://github.com/sqlmapproject/sqlmap
mv sqlmap $HOME
cd $HOME/sqlmap
python2 sqlmap.py -h
fi

if [ $asu = 4 ] || [ $asu = 4 ]
then
clear
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
cd h2r
php sql1.php
fi

if [ $asu = 5 ] || [ $asu = 5 ]
then
clear
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
apt install git
git clone https://github.com/UltimateHackers/XSStrike
mv XSStrike $HOME
cd $HOME/XSStrike
pip install -r requirements.txt
python xsstrike.py
fi

if [ $asu = 6 ] || [ $asu = 6 ]
then
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
git clone https://github.com/Bhai4You/Ip-Attack
mv Ip-Attack $HOME
cd $HOME/Ip-Attack
bash requirement.sh
python2 ip-attack.py
fi

if [ $asu = 7 ] || [ $asu = 7 ]
then
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
git clone https://github.com/websploit/websploit
mv websploit $HOME
cd $HOME/websploit
python setup.py install
websploit
fi

if [ $asu = 8 ] || [ $asu = 8 ]
then
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
git clone https://github.com/BullsEye0/google_dork_list.git
mv google_dork_list $HOME
cd $HOME/google_dork_list
cat google_dork_list.txt
fi

if [ $asu = 9 ] || [ $asu = 9 ]
then
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
apt install python
cd h2r
python2 Whoami.py
fi

if [ $asu = 10 ] || [ $asu = 10 ]
then
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
apt install python2
apt install git
wget -O rapidscan.py https://raw.githubusercontent.com/skavngr/rapidscan/master/rapidscan.py && chmod +x rapidscan.py
mv rapidscan.py $HOME
cd $HOME
python2 rapidscan.py
fi

if [ $asu = 11 ] || [ $asu = 11 ]
then
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
git clone https://github.com/opsdisk/pagodo.git
mv pagodo $HOME
cd $HOME/pagodo
pip install -r requirements.txt
python pagodo.py
fi

if [ $asu = 12 ] || [ $asu = 12 ]
then
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
pip2 install sh
git clone https://github.com/Gameye98/AstraNmap
mv AstraNmap $HOME
cd $HOME/AstraNmap
sh astranmap.sh
fi

if [ $asu = 13 ] || [ $asu = 13 ]
then
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
pkg update && pkg upgrade
pkg install git 
pkg install python2
git clone https://github.com/ciku370/ko-dork.git
mv ko-dork $HOME
cd $HOME/ko-dork
python2 dork.py
fi

if [ $asu = 14 ] || [ $asu = 14 ]
then
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
git clone https://github.com/anouarbensaad/vulnx
mv vulnx $HOME
cd $HOME/vulnx
chmod +x install.sh
./install.sh
fi

if [ $asu = 15 ] || [ $asu = 15 ]
then
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
echo " Copas Link Ini Dan Tempel Di Browser Kalian"
echo ""
echo " https://github.com/hahwul/WebHackersWeapons"
echo ""
echo " Dan Pilih Tools Sesuai Kebutuhan Kalian"
fi

if [ $asu = 0 ] || [ $asu = 0 ]
then
echo -e "Abyss Walker" | lolcat
echo -e "No System Is Safe" | lolcat
echo -e "Be Carrefuly On Internet" | lolcat
echo -e "Malware Everywhere" | lolcat
echo -e "Thanks For Use This Tools" | lolcat
exit
fi

