#!/system/xbin/bash

apt install bash -y
apt install python -y
apt install figlet -y
apt install ruby -y
gem install lolcat -y
apt install toilet -y
apt install python2 -y
apt install cowsay -y
pip2 install requests
pip2 install mechanize
pip install requests
pip install mechanize
